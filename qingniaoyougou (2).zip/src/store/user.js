export default {
	namespaced: true,
	state: {
		address: {},
		flag: false,
		user:{
			code:'',
			encryptedData:'',
			iv:'',
			rawData:'',
			signature:''
		}
	},
	mutations: {
		updataAddress(state, res) {
			state.address = res
			state.flag = true
		},
		login(state,res){
			console.log(res)
			state.user.code = res.code
		},
		userInfo(state,res){
			console.log(res)
			state.user.encryptedData = res.encryptedData
			state.user.iv = res.iv
			state.user.rawData = res.rawData
			state.user.signature = res.signature
		},
		wxInfo(state,res){
			console.log('wx',res)
		}

	},
	actions: {
		getAddress(state) {
			uni.chooseAddress({
				success(res) {
					state.commit('updataAddress', res)
				}
			})
		},
		uniLogin(state){
			uni.getUserInfo({
				success: (res) => {
					state.commit('userInfo', res)
				},
				fail: (error) => {}
			})
			uni.login({
				success: (result) => {
					state.commit('login', result)
				},
				fail: (error) => {}
			}),
			wx.getUserProfile({
				desc:'学习中捏',
				success:(res)=>{
					state.commit('wxInfo', res)
				}
			})
			
		}
	}
}
