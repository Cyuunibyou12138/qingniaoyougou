<template>
	<view>
		<view class="login">
			<view class="userIcon">
				<uni-icons type="contact-filled" color="rgb(175,175,175)" size="100"></uni-icons>
			</view>
			<view class="btn" @click="uniLogin">一键登录</view>
			<view >登陆后尽享更多权益</view>
		</view>
	</view>
</template>

<script>
	import mix from '@/mixins/mixins'
	import { mapState,mapActions } from 'vuex'
	export default {
		mixins: [mix],
		data() {
			return {}
		},
		computed: {},
		methods: {
			...mapActions('user',['uniLogin'])
		}
	}
</script>

<style lang="scss">
	.login {
		margin-top: 150rpx;
		width: 100%;
		text-align: center;
		> view {
			&.btn {
				margin-top: 50rpx;
				background-color: rgb(204, 4, 4);
				border-radius: 50rpx;
				height: 100rpx;
				line-height: 100rpx;
				color: white;
				width: 90%;
				display: inline-block;
			}
			&:nth-child(3){
				margin-top: 20rpx;
				font-size: 24rpx;
				color: rgb(128,128,128);
			}
		}
	}
</style>
