module.exports = {
	transpileDependencies: ['@dcloudio/uni-ui']
}